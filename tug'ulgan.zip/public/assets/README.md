# Music Assets Directory
Joylashtirmoqchi bo‘lgan musiqangizni shu yerga `music.mp3` nomi bilan yuklang.
Place your desired background music file here named `music.mp3`.
Audio element path: `assets/music.mp3`
